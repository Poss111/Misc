package harddrivemanager;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.Arrays;

/**
 * @author Dan Poss
 * @version Nov 1, 2015
 * CSCI 460: Operating Systems
 * Assignment 3
 * Simulation of Device Management Strategies (FCFS, SSTF, LOOK, CLOOK)
 */

// Seek time = 10 + 0.1 * T ms, T = number of tracks of motion from 
//  one request to the next.
// Rotation to a sector takes 1ms

public class HarddriveManager {

    trackList tl[] = new trackList[50];               // Random track list for 
                                                        //  computing averages.
                                                        //  Also used to decide
                                                        //  usefullness of each
                                                        //  optimizaiton strat.
    trackList sample[] = new trackList[10];             // Sample track list
                                                        //  that was given.
    int startSector = 0;                                // Starting sector for 
                                                        //  read/write head.
    int startTrack = 0;                                 // Starting track for
                                                        //  read/write head.
    
    DecimalFormat numFormat = new DecimalFormat("#.00");
    
    public static void main(String[] args) {
        HarddriveManager hdd = new HarddriveManager();
        hdd.readWriteHead();
    }
    
    public void readWriteHead() {
        Random rnd = new Random();
                
        sample[0] = new trackList(0,54,0);          // Initialized given track
        sample[1] = new trackList(23,132,6);        // list.
        sample[2] = new trackList(26,29,2);
        sample[3] = new trackList(29,23,1);
        sample[4] = new trackList(35,198,7);
        sample[5] = new trackList(45,170,5);
        sample[6] = new trackList(57,180,3);
        sample[7] = new trackList(83,78,4);
        sample[8] = new trackList(88,73,5);
        sample[9] = new trackList(95,249,7); 
        
        System.out.println("Sample Set");
        FCFS(sample);
        SSTF(sample);
        Look(sample);
        CLook(sample);
        
        for (int i = 0; i < tl.length; i++) {
            int a = rnd.nextInt(99);
            int b = rnd.nextInt(249);
            int c = rnd.nextInt(7);
            tl[i] = new trackList(a,b,c);
        }
        
        sort(tl);
        
        System.out.println();

        System.out.println("Random Set");
        
        FCFS(tl);
        SSTF(tl);
        Look(tl);
        CLook(tl);        
    }
    
    public void FCFS(trackList[] tracks) {
        int systemCounter = -1;                      // Counter for FCFS
        double totalTime = 0;
        startTrack = 0;
        startSector = 0;
        
        double turnAroundTimes[] = new double[tracks.length]; 
        while ((systemCounter + 1) < tracks.length) {
            if (systemCounter == -1) {
                totalTime = seekTime(startTrack, startSector,
                                    tracks[systemCounter + 1].trackNumber,
                                    tracks[systemCounter + 1].sectorRequested);
//                System.out.println("0: " + turnAroundTime);
                systemCounter++;
                turnAroundTimes[systemCounter] = totalTime -
                        tracks[systemCounter].arrivalTime;
            }
            else {
                double temp = seekTime(tracks[systemCounter].trackNumber,
                                    tracks[systemCounter].sectorRequested,
                                    tracks[systemCounter + 1].trackNumber,
                                    tracks[systemCounter + 1].sectorRequested);
                totalTime += temp;
//                System.out.print(systemCounter + ": " + turnAroundTime);
//                System.out.println(" " + tracks[systemCounter].trackNumber + 
//                        " " + tracks[systemCounter].sectorRequested +
//                        " " + tracks[systemCounter + 1].trackNumber +
//                        " " + tracks[systemCounter + 1].sectorRequested);
                systemCounter++;
                if (systemCounter != tracks.length) {
                    turnAroundTimes[systemCounter] = temp;
                }
            }
        }

        System.out.println(" FCFS");
        stats(turnAroundTimes, totalTime);
    }
    
    public void SSTF(trackList[] tracks) {
        int systemCounter = -1;                     // Counter for SSTF
        double totalTime = 0;  
        startTrack = 0;
        startSector = 0;        
        
        double turnAroundTimes[] = new double[tracks.length];
        int usedArrayNum[] = new int[tracks.length];
        
        for (int k = 0; k < tracks.length; k++) {
            usedArrayNum[k] = -1;
        }
        
        while ((systemCounter+1) < tracks.length) {
            if (systemCounter == -1) {
                totalTime = seekTime(startTrack, startSector,
                                    tracks[systemCounter + 1].trackNumber,
                                    tracks[systemCounter + 1].sectorRequested);
//                System.out.print(startTrack + " -> " + tracks[systemCounter + 1].trackNumber + " = ");
//                System.out.println("0: " + totalTime); 
                startTrack = tracks[systemCounter + 1].trackNumber;
                systemCounter++;
                turnAroundTimes[systemCounter] = totalTime -
                        tracks[systemCounter].arrivalTime;
                usedArrayNum[0] = 0;
            }
            else {
                if (tracks[systemCounter+1].arrivalTime > totalTime) {
                    totalTime = tracks[systemCounter+1].arrivalTime;
                    double temp = seekTime(tracks[systemCounter].trackNumber,
                        tracks[systemCounter].sectorRequested,
                        tracks[systemCounter + 1].trackNumber,
                        tracks[systemCounter + 1].sectorRequested);
                    totalTime += temp;
//                    System.out.print(tracks[systemCounter].trackNumber + " -> " + tracks[systemCounter + 1].trackNumber + " = ");
//                    System.out.println(temp);
                    startTrack = tracks[systemCounter + 1].trackNumber;
                    systemCounter++;
                    usedArrayNum[systemCounter] = systemCounter;
                    usedArrayNum[systemCounter + 1] = systemCounter + 1;
                    if (systemCounter != tracks.length) {
                        turnAroundTimes[systemCounter] = temp;                      
                    }
                }
                else {
                    int closestTrack = 249;
                    int numInArray = 0;
                    int trackToJumpTo = 0;
                    boolean checker = false;
                    for (int i = 0; i < tracks.length; i++) {
                        if (tracks[i].arrivalTime > totalTime) {
                            break;
                        }
                        for (int j = 0; j < usedArrayNum.length; j++) {
                            if (i == usedArrayNum[j]) {
                                checker = true;
//                                System.out.println("This has been used -> " + i );
                                break;
                            }
                        }
                        if (checker == true) {
                            checker = false;
                        }
                        else if (tracks[i].trackNumber > startTrack) {
                            trackToJumpTo = tracks[i].trackNumber - startTrack;
                            if (trackToJumpTo < closestTrack) {
                                closestTrack = trackToJumpTo;
                                numInArray = i;
                            }
                        }
                        else if (tracks[i].trackNumber < startTrack) {
                            trackToJumpTo = startTrack - tracks[i].trackNumber;
                            if (trackToJumpTo < closestTrack) {
                                closestTrack = trackToJumpTo;
                                numInArray = i;
                            }
                        }
                    }
                    
//                    System.out.println("Closest to " + startingTrack + " is " + tracks[numInArray].trackNumber);
                    usedArrayNum[systemCounter+1] = numInArray;
                    for (int i = 0; i < tracks.length; i++) {
                        if (startTrack == tracks[i].trackNumber) {
                            startSector = tracks[i].sectorRequested;
                        }
                    }
                    double temp = seekTime(startTrack,
                                        startSector,
                                        tracks[numInArray].trackNumber,
                                        tracks[numInArray].sectorRequested);
//                    System.out.print(startTrack + " -> " + tracks[numInArray].trackNumber + " = ");
                    startTrack = tracks[numInArray].trackNumber;                    
//                    System.out.println(temp);
                    totalTime += temp;
//                  System.out.print(systemCounter + ": " + turnAroundTime);
//                  System.out.println(" " + tracks[systemCounter].trackNumber + 
//                        " " + tracks[systemCounter].sectorRequested +
//                        " " + tracks[systemCounter + 1].trackNumber +
//                        " " + tracks[systemCounter + 1].sectorRequested);
                    systemCounter++;
                    if (systemCounter != (tracks.length-1)) {
                        turnAroundTimes[systemCounter] = temp;  
                    }
                }
            }
        }
        System.out.println(" SSTF");
        stats(turnAroundTimes, totalTime);
    }
    
    public void Look(trackList[] tracks) {
        int systemCounter = -1;                     // Counter for SSTF
        double totalTime = 0;  
        startTrack = 0;
        startSector = 0;
        boolean movingRight = true;
        
        double turnAroundTimes[] = new double[tracks.length];
        int usedArrayNum[] = new int[tracks.length];
        
        for (int k = 0; k < tracks.length; k++) {
            usedArrayNum[k] = -1;
        }
        
        while ((systemCounter+1) < tracks.length) {
            if (systemCounter == -1) {
                totalTime = seekTime(startTrack, startSector,
                                    tracks[systemCounter + 1].trackNumber,
                                    tracks[systemCounter + 1].sectorRequested);
//                System.out.print(startTrack + " -> " + tracks[systemCounter + 1].trackNumber + " = ");
//                System.out.println("0: " + totalTime); 
                startTrack = tracks[systemCounter + 1].trackNumber;
                systemCounter++;
                turnAroundTimes[systemCounter] = totalTime -
                        tracks[systemCounter].arrivalTime;
                usedArrayNum[0] = 0;
            }
            else {
                if (tracks[systemCounter+1].arrivalTime > totalTime) {
                    totalTime = tracks[systemCounter+1].arrivalTime;
                    double temp = seekTime(tracks[systemCounter].trackNumber,
                        tracks[systemCounter].sectorRequested,
                        tracks[systemCounter + 1].trackNumber,
                        tracks[systemCounter + 1].sectorRequested);
                    totalTime += temp;
//                    System.out.print(tracks[systemCounter].trackNumber + " -> " + tracks[systemCounter + 1].trackNumber + " = ");
//                    System.out.println(temp);
                    startTrack = tracks[systemCounter + 1].trackNumber;
                    systemCounter++;
                    usedArrayNum[systemCounter] = systemCounter;
                    if (systemCounter != tracks.length) {
                        turnAroundTimes[systemCounter] = temp;                      
                    }
                }
                else {
                    int closestTrack = 249;
                    int numInArray = 0;
                    int trackToJumpTo = 0;
                    boolean checker = false;
                    for (int i = 0; i < tracks.length; i++) {
                        if (tracks[i].arrivalTime > totalTime) {
                            break;
                        }
                        for (int j = 0; j < usedArrayNum.length; j++) {
                            if (i == usedArrayNum[j]) {
                                checker = true;
//                                System.out.println("This has been used -> " + i + " " + tracks[i].trackNumber);
                                break;
                            }
                        }
                        if (checker == true) {
                            checker = false;
                        }
                        else if (movingRight == true) {
                            if (tracks[i].trackNumber > startTrack) {
                                trackToJumpTo = tracks[i].trackNumber - startTrack;
                                if (trackToJumpTo < closestTrack) {
                                    closestTrack = trackToJumpTo;
                                    numInArray = i;
                                    if ((i + 1) == tracks.length) {
                                        movingRight = false;
                                    }
                                }
                            }
                        }
                        else if (movingRight == false) {
                            if (tracks[i].trackNumber < startTrack) {
                                trackToJumpTo = startTrack - tracks[i].trackNumber;
                                if (trackToJumpTo < closestTrack) {
                                    closestTrack = trackToJumpTo;
                                    numInArray = i;
                                }
                            } 
                            else if (tracks[i].trackNumber > startTrack) {
                                trackToJumpTo = tracks[i].trackNumber - startTrack;
                                if (trackToJumpTo < closestTrack) {
                                    closestTrack = trackToJumpTo;
                                    numInArray = i;
                                }
                            }
                        }
                    }
                    
//                    System.out.println("Closest to " + startTrack + " is " + tracks[numInArray].trackNumber);
                    for (int c = 0; c < usedArrayNum.length; c++) {
                        if (usedArrayNum[c] == -1) {
                            usedArrayNum[c] = numInArray;
                            break;
                        }
                    }
                    for (int i = 0; i < tracks.length; i++) {
                        if (startTrack == tracks[i].trackNumber) {
                            startSector = tracks[i].sectorRequested;
                        }
                    }
                    double temp = seekTime(startTrack,
                                        startSector,
                                        tracks[numInArray].trackNumber,
                                        tracks[numInArray].sectorRequested);
//                    System.out.print(startTrack + " -> " + tracks[numInArray].trackNumber + " = ");
                    startTrack = tracks[numInArray].trackNumber;                    
//                    System.out.println(temp);
                    totalTime += temp;
//                  System.out.print(systemCounter + ": " + turnAroundTime);
//                  System.out.println(" " + tracks[systemCounter].trackNumber + 
//                        " " + tracks[systemCounter].sectorRequested +
//                        " " + tracks[systemCounter + 1].trackNumber +
//                        " " + tracks[systemCounter + 1].sectorRequested);
                    systemCounter++;
                    if (systemCounter != (tracks.length-1)) {
                        turnAroundTimes[systemCounter] = temp;  
                    }
                }
            }
        }
        
        System.out.println(" Look");
        stats(turnAroundTimes, totalTime);
    }
    
    public void CLook(trackList[] tracks) {
    int systemCounter = -1;                     // Counter for CLook
        double totalTime = 0;  
        startTrack = 0;
        startSector = 0;
        int smallest = tracks[0].trackNumber;
        int position = 0;
        boolean movingRight = true;
        
        double turnAroundTimes[] = new double[tracks.length];
        int usedArrayNum[] = new int[tracks.length];
        
        for (int k = 0; k < tracks.length; k++) {
            usedArrayNum[k] = -1;
        }
        
        for (int k = 1; k < tracks.length; k++) {
            if (tracks[k].trackNumber < smallest) {
                smallest = tracks[k].trackNumber;
                position = k;
            }
        }
        
        while ((systemCounter+1) < tracks.length) {
            if (systemCounter == -1) {
                totalTime = seekTime(startTrack, startSector,
                                    tracks[systemCounter + 1].trackNumber,
                                    tracks[systemCounter + 1].sectorRequested);
//                System.out.print(startTrack + " -> " + tracks[systemCounter + 1].trackNumber + " = ");
//                System.out.println("0: " + totalTime); 
                startTrack = tracks[systemCounter + 1].trackNumber;
                systemCounter++;
                turnAroundTimes[systemCounter] = totalTime -
                        tracks[systemCounter].arrivalTime;
                usedArrayNum[0] = 0;
            }
            else {
                if (tracks[systemCounter+1].arrivalTime > totalTime) {
                    totalTime = tracks[systemCounter+1].arrivalTime;
                    double temp = seekTime(tracks[systemCounter].trackNumber,
                        tracks[systemCounter].sectorRequested,
                        tracks[systemCounter + 1].trackNumber,
                        tracks[systemCounter + 1].sectorRequested);
                    totalTime += temp;
//                    System.out.print(tracks[systemCounter].trackNumber + " -> " + tracks[systemCounter + 1].trackNumber + " = ");
//                    System.out.println(temp);
                    startTrack = tracks[systemCounter + 1].trackNumber;
                    systemCounter++;
                    usedArrayNum[systemCounter] = systemCounter;
                    if (systemCounter != tracks.length) {
                        turnAroundTimes[systemCounter] = temp;                      
                    }
                }
                else {
                    int closestTrack = 249;
                    int numInArray = 0;
                    int trackToJumpTo = 0;
                    boolean checker = false;
                    for (int i = 0; i < tracks.length; i++) {
                        if (tracks[i].arrivalTime > totalTime) {
                            break;
                        }
                        for (int j = 0; j < usedArrayNum.length; j++) {
                            if (i == usedArrayNum[j]) {
                                checker = true;
//                                System.out.println("This has been used -> " + i + " " + tracks[i].trackNumber);
                                break;
                            }
                        }
                        if (checker == true) {
                            checker = false;
                        }
                        else if (movingRight == true) {
                            if (tracks[i].trackNumber > startTrack) {
                                trackToJumpTo = tracks[i].trackNumber - startTrack;
                                if (trackToJumpTo < closestTrack) {
                                    closestTrack = trackToJumpTo;
                                    numInArray = i;
                                    if ((i + 1) == tracks.length) {
                                        movingRight = false;
                                    }
                                }
                            }
                        }
                        else if (movingRight == false) {
                            numInArray = position;
                            movingRight = true;
                        }
                    }
                    
//                    System.out.println("Closest to " + startTrack + " is " + tracks[numInArray].trackNumber);
                    for (int c = 0; c < usedArrayNum.length; c++) {
                        if (usedArrayNum[c] == -1) {
                            usedArrayNum[c] = numInArray;
                            break;
                        }
                    }
                    for (int i = 0; i < tracks.length; i++) {
                        if (startTrack == tracks[i].trackNumber) {
                            startSector = tracks[i].sectorRequested;
                        }
                    }
                    double temp = seekTime(startTrack,
                                        startSector,
                                        tracks[numInArray].trackNumber,
                                        tracks[numInArray].sectorRequested);
//                    System.out.print(startTrack + " -> " + tracks[numInArray].trackNumber + " = ");
                    startTrack = tracks[numInArray].trackNumber;                    
//                    System.out.println(temp);
                    totalTime += temp;
//                  System.out.print(systemCounter + ": " + turnAroundTime);
//                  System.out.println(" " + tracks[systemCounter].trackNumber + 
//                        " " + tracks[systemCounter].sectorRequested +
//                        " " + tracks[systemCounter + 1].trackNumber +
//                        " " + tracks[systemCounter + 1].sectorRequested);
                    systemCounter++;
                    if (systemCounter != (tracks.length-1)) {
                        turnAroundTimes[systemCounter] = temp;  
                    }
                }
            }
        }

        System.out.println(" CLook");
        stats(turnAroundTimes, totalTime);
    }
    
    public void stats(double turnAroundTimes[], double totalTime) {
        int counter = 0;
        double mean = 0;
        double variance = 0;
        double differences[] = new double[turnAroundTimes.length];
        double std = 0;
        while (counter != turnAroundTimes.length) {
            mean += turnAroundTimes[counter];
//            System.out.println(turnAroundTimes[counter]);
            counter++;
        }
        counter = 0;
        mean = mean / turnAroundTimes.length;
        
        while (counter != turnAroundTimes.length) {
            differences[counter] = pow(mean - turnAroundTimes[counter],2.0);
            variance += differences[counter];
            counter++;
        }
        
        variance = variance / turnAroundTimes.length;
        std = sqrt(variance);
//        System.out.println("   Total Time: " + numFormat.format(totalTime));
        System.out.println("   Mean:       " + numFormat.format(mean));
        System.out.println("   Variance:   " + numFormat.format(variance));
        System.out.println("   Std:        " + numFormat.format(std));                
    }
    
    public double seekTime(int trackOne, int sectorOne, int trackTwo, int sectorTwo) {
        double result = 0;
        if (trackTwo > trackOne) {
            result = 10 + 0.1 * (trackTwo - trackOne);
            if (sectorOne < sectorTwo) {
                result += (sectorTwo - sectorOne);
//                System.out.print("11R: " + result + " ");
                return result;
            }
            else if (sectorOne > sectorTwo) {
                result += ((7 - sectorOne) + (sectorTwo + 1));
//                System.out.print("12R: " + result + " ");
                return result;
            }
//            System.out.print("1R: " + result + " ");
            return result;
        }
        else if (trackTwo < trackOne) {
            result = 10 + 0.1 * (trackOne - trackTwo);
            if (sectorOne < sectorTwo) {
                result += (sectorTwo - sectorOne);
//                System.out.print("21R: " + result + " ");
                return result;
            }
            else if (sectorOne > sectorTwo) {
                result += (( 7 - sectorOne) + (sectorTwo + 1));
//                System.out.print("S1 " + sectorOne + " S2 " + sectorTwo +" ");
//                System.out.print("22R: " + result + " ");
                return result;
            }
//            System.out.print("2R: " + result + " ");
            return result;
        }
//        System.out.print("R: " + result + " ");
        return result;
    }
    
    public void sort(trackList[] list) {
        int n = list.length;
        trackList temp = new trackList(0,0,0);
        
        for (int i = 0; i < n; i++) {
            for (int j = 1; j < (n-i); j++) {
                if (list[j-1].arrivalTime > list[j].arrivalTime) {
                    temp = list[j-1];
                    list[j-1] = list[j];
                    list[j] = temp;               
                }
            }
        }
    }
}
