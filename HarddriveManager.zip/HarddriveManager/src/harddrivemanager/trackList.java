package harddrivemanager;


/**
 * @author Dan Poss
 * @date Nov 1, 2015
 */

public class trackList {

    int arrivalTime = 0;
    int trackNumber = 0;
    int sectorRequested = 0;
    
    public trackList(int arrivalTime, int trackNumber, int sectorRequested) {
        this.arrivalTime = arrivalTime;
        this.trackNumber = trackNumber;
        this.sectorRequested = sectorRequested;
    }
    
    public void setArrivalTime(int at) {
        arrivalTime = at;
    }
    
    public void setTrackNumber(int trackNum) {
        trackNumber = trackNumber;
    }
    
    public void setSectorRequest(int sectorReq) {
        sectorRequested = sectorReq;
    }
    
    public int getArrivalTime() {
        return arrivalTime;
    }
    
    public int getTrackNumber() {
        return trackNumber;
    }
    
    public int getSectorReq() {
        return sectorRequested;
    }
}
