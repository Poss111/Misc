package proccessormanagement;

/**
 * @author Dan Poss
 * @version Sep 13, 2015
 */

import java.util.concurrent.*;

public class ProccessorManagement{
    
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    int add1, add2; 
   
    public static void main(String[] args) {
        ProccessorManagement pm = new ProccessorManagement();
        pm.ProccessorManagement();
    }
    
    public void ProccessorManagement() {
        P1();
    }
    
    public void P1() {
        final Runnable proccess = new Runnable() {
            public void run() { System.out.println("beep");
            P2(20, "Proccess One"); }
        };
        final ScheduledFuture<?> proccessHandle =
                scheduler.scheduleAtFixedRate(proccess, 0, 1, TimeUnit.SECONDS);
        scheduler.schedule(new Runnable() {
            public void run() { proccessHandle.cancel(true); }
        }, 10, TimeUnit.SECONDS);
    }
    
    public void P2(int proccessTime, String proccessName) {
        add1 += proccessTime;
        add2 += 2;
        int sum = add1 + add2;
        System.out.println(sum);
    }
    
    public void P3() {
        
    }
}
