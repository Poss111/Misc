package recieverudp;

import java.net.*;
import java.io.*;

/**
 * @author Dan Poss
 * @version Oct 1, 2015
 */

public class RecieverUDP {

    public static void main(String[] args) {
        StringInt window[] = new StringInt[10];
        try{
            boolean stillRecieving = true;
            DatagramSocket recieverSocket = new DatagramSocket(9876);
            byte[] rcvData = new byte[1024];
            byte[] sendData = new byte[10];
            DatagramPacket rcvPkt = new DatagramPacket(rcvData, rcvData.length);
            int counter = 0;
            recieverSocket.receive(rcvPkt);
            InetAddress IPAddress = rcvPkt.getAddress();
            DatagramPacket sendPkt = new DatagramPacket(sendData, sendData.length, IPAddress, rcvPkt.getPort());
            sendData[0] = 1;
            sendData[1] = rcvData[1];
            recieverSocket.send(sendPkt);
            while (stillRecieving) {
                int pktsToRecieve = rcvData[0];
                for (int i = 0; i < pktsToRecieve; i++) {
                    window[i] = new StringInt(i,"");
                }
                if (pktsToRecieve > counter) {
                    counter++;
                    if(counter == 10) {
                        int port = rcvPkt.getPort();
                        System.out.println("Packet " + rcvData[1] + " is received, send Ack" + rcvData[1] 
                        + ", window [" + window[0].getNumber() + ","
                            + window[1].getNumber() + "," 
                            + window[2].getNumber() + "," 
                            + window[3].getNumber() + "]");                        
                        System.out.println("HI");
                        System.exit(0);
                    }
                    int port = rcvPkt.getPort();
                    System.out.println("Packet " + rcvData[1] + " is received, send Ack" + rcvData[1] 
                        + ", window [" + window[0].getNumber() + ","
                            + window[1].getNumber() + "," 
                            + window[2].getNumber() + "," 
                            + window[3].getNumber() + "]");
                    recieverSocket.receive(rcvPkt);
                    sendData[0] = 1;
                    sendData[1] = rcvData[1];
                    recieverSocket.send(sendPkt);
                }
            }
            recieverSocket.close();
            System.exit(0);
        }
        catch(IOException e) {
            
        }
    }
}
