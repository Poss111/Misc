package recieverudp;

import java.net.*;
import java.io.*;

/**
 * @author Dan Poss
 * @version Oct 1, 2015
 */

public class RecieverUDP {

    public static void main(String[] args) {
        StringInt window[] = new StringInt[10];
        try{
            boolean stillRecieving = true;
            DatagramSocket recieverSocket = new DatagramSocket(9876);
            DatagramSocket senderSocket =  new DatagramSocket(9874);
            byte[] rcvData = new byte[1024];
            byte[] sendData = new byte[10];
            DatagramPacket rcvPkt = new DatagramPacket(rcvData, rcvData.length);
            while (stillRecieving) {
                recieverSocket.receive(rcvPkt);
                int pktsToRecieve = rcvData[0];
                for (int i = 0; i < pktsToRecieve; i++) {
                    window[i] = new StringInt(i,"");
                }
                InetAddress IPAddress = rcvPkt.getAddress();
                if (pktsToRecieve <= rcvData[0]) {
                    DatagramPacket sendPkt = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
                    int port = rcvPkt.getPort();
                    System.out.println("Packet " + rcvData[1] + " is received, send Ack" + rcvData[1] 
                        + ", window [" + window[0].getNumber() + ","
                            + window[1].getNumber() + "," 
                            + window[2].getNumber() + "," 
                            + window[3].getNumber() + "]");
                    sendData[0] = 1;
                    sendData[1] = rcvData[1];
                    senderSocket.send(sendPkt);
                }
                else {
                    stillRecieving = false;
                }
            }
            recieverSocket.close();
            System.exit(0);
        }
        catch(IOException e) {
            
        }
    }
}
