package recieverudp;

import java.net.*;
import java.io.*;

/**
 * @author Dan Poss & Karl Wilson
 * @version Oct 6, 2015
 */

public class RecieverUDP {

    public static void main(String[] args) {
        try{
            boolean stillRecieving = true;
            int windowSize = 0;
            int pktsToRecieve = 0;
            DatagramSocket recieverSocket = new DatagramSocket(9876);
            byte[] rcvData = new byte[1024];
            byte[] sendData = new byte[10];
            DatagramPacket rcvPkt = new DatagramPacket(rcvData, rcvData.length);
            int counter = 0;
            recieverSocket.receive(rcvPkt);
            InetAddress IPAddress = rcvPkt.getAddress();
            DatagramPacket sendPkt = new DatagramPacket(sendData, sendData.length, IPAddress, rcvPkt.getPort());
            sendData[0] = 1;
            sendData[1] = rcvData[1];
            pktsToRecieve = rcvData[0];
            windowSize = rcvData[2];
            StringInt window[] = new StringInt[pktsToRecieve+windowSize];
            for (int i = 0; i < pktsToRecieve; i++) {
                window[i] = new StringInt(i, "");
            }
            for (int j = pktsToRecieve; j < windowSize+pktsToRecieve; j++) {
                window[j] = new StringInt(pktsToRecieve, "-");
            }            
            recieverSocket.send(sendPkt);
            while (stillRecieving) {
                for (int i = 0; i < pktsToRecieve; i++) {
                    window[i] = new StringInt(i,"");
                }
                if (pktsToRecieve > counter) {
                    counter++;
                    if(counter == 10) {
                        int port = rcvPkt.getPort();
                        System.out.print("Packet " + rcvData[1] + " is received, send Ack" + rcvData[1] + ", window ["); 
                        for (int i = counter; i < windowSize + counter; i++) {
                            if (window[i].getNumber() != pktsToRecieve){
                                System.out.print(window[i].getNumber() + window[i].getAsterisk());
                                if (i < ((windowSize + counter) - 1)) { 
                                    System.out.print(",");
                                }
                            }
                            else if (window[i].getAsterisk() == "-"){
                                System.out.print("-");
                                if (i < ((windowSize + counter) - 1)) { 
                                    System.out.print(",");
                                }                                        
                            }
                        }  
                        System.out.println("]");
                        System.exit(0);
                    }
                    int port = rcvPkt.getPort();
                    System.out.print("Packet " + rcvData[1] + " is received, send Ack" + rcvData[1] + ", window ["); 
                    for (int i = counter; i < windowSize + counter; i++) {
                        if (window[i].getNumber() != pktsToRecieve){
                            System.out.print(window[i].getNumber() + window[i].getAsterisk());
                            if (i < ((windowSize + counter) - 1)) { 
                                System.out.print(",");
                            }
                        }
                        else if (window[i].getAsterisk() == "-"){
                            System.out.print("-");
                            if (i < ((windowSize + counter) - 1)) { 
                                System.out.print(",");
                            }                                        
                        }
                    }  
                    System.out.println("]");
                    recieverSocket.receive(rcvPkt);
                    sendData[0] = 1;
                    sendData[1] = rcvData[1];
                    recieverSocket.send(sendPkt);
                }
            }
            recieverSocket.close();
        }
        catch(IOException e) {
            
        }
    }
}
