package senderudp;

import java.net.*;
import java.util.*;
import java.io.*;
import java.nio.ByteBuffer;

/**
 * @author Dan Poss & Karl Wilson
 * @version Oct 6, 2015
 */

public class SenderUDP {

    public static void main(String[] args) {
        int windowSize = 0;
        int sequenceNum = 0;
        int missingPkt = 0;
        int windowTracker = 0;
        byte[] sendData = new byte[1024];
        byte[] rcvData = new byte[1024];
        boolean sending = true;
        int counter = 0;
        Scanner in = new Scanner(System.in);
        try{
            System.out.print("Enter the window's size on the sender: " );
            windowSize = in.nextInt();
            System.out.print("Enter the maximum sequence number on the sender: ");
            sequenceNum = in.nextInt();
            System.out.print("Select the packet(s) that will be dropped: ");
            missingPkt = in.nextInt();
            StringInt window[] = new StringInt[sequenceNum + windowSize];
            for (int i = 0; i < sequenceNum; i++) {
                window[i] = new StringInt(i, "");
            }
            for (int j = sequenceNum; j < windowSize+sequenceNum; j++) {
                window[j] = new StringInt(sequenceNum, "-");
            }
            DatagramSocket senderSocket = new DatagramSocket(9877);
            InetAddress IPAddress = InetAddress.getByName("localhost");
            int j = 0;
            DatagramPacket sendPkt[] = new DatagramPacket[sequenceNum];
            DatagramPacket rcvPkt = new DatagramPacket(rcvData, rcvData.length);
            while(sending) {
                if (j != sequenceNum) {
//                    if (j == missingPkt) {
//                        j++;
//                    }
                    sendData[0] = (byte) sequenceNum;
                    sendData[1] = (byte) j;
                    sendData[2] = (byte) windowSize;
                    window[j].setString("*");
                    System.out.print("Packet " + j + " is sent, window[");
                    for (int i = windowTracker; i < windowSize+windowTracker; i++) {
                        System.out.print(window[i].getNumber() + window[i].getAsterisk());
                        if (i < ((windowSize+windowTracker)-1)) { 
                            System.out.print(",");
                        }
                    }
                    System.out.println("]");
                    sendPkt[j] = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
                    senderSocket.send(sendPkt[j]);
                    j++;
                    if (j > (windowSize-1)) {
                        senderSocket.receive(rcvPkt);
//                        if (windowTracker == rcvData[1])
//                            windowTracker++;
//                        else if (rcvData[1] == ((windowSize + windowTracker) - 1)) {
//                            System.out.println("Packet " + windowTracker + " times out, resend packet 2");
//                            sendData[1] = (byte) windowTracker;
//                            DatagramPacket sendPktAgain = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
//                            senderSocket.send(sendPktAgain);
//                            System.out.print("Packet " + windowTracker + " is sent, window[");
//                            for (int i = windowTracker; i < windowSize+windowTracker; i++) {
//                                if (window[i].getNumber() != sequenceNum){
//                                    System.out.print(window[i].getNumber());
//                                    if (i < ((windowSize + windowTracker) - 1)) { 
//                                        System.out.print(",");
//                                    }
//                                }
//                                else if (window[i].getAsterisk() == "-"){
//                                    System.out.print("-");
//                                    if (i < ((windowSize+windowTracker)-1)) { 
//                                        System.out.print(",");
//                                    }                                        
//                                }
//                            }
//                            System.out.println("]");
//                        }
                        windowTracker++;
                        System.out.print("Ack " + rcvData[1] + " received, window[");
                        for (int i = windowTracker; i < windowSize+windowTracker; i++) {
                            if (window[i].getNumber() != sequenceNum){
                                System.out.print(window[i].getNumber() + window[i].getAsterisk());
                                if (i < ((windowSize+windowTracker)-1)) { 
                                    System.out.print(",");
                                }
                            }
                            else if (window[i].getAsterisk() == "-"){
                                System.out.print("-");
                                if (i < ((windowSize+windowTracker)-1)) { 
                                    System.out.print(",");
                                }                                        
                            }
                        }
                        System.out.println("]");
                        counter ++;
                    }
                } 
                else if(counter < sequenceNum) {
                    windowTracker++;
//                    if (window[counter].getNumber() == sequenceNum) {
//                        window[counter].setNumber() = "-";
//                    }
                    counter ++;
                    senderSocket.receive(rcvPkt);
                    System.out.print("Ack " + rcvData[1] + " received, window[");
                    for (int i = windowTracker; i < windowSize+windowTracker; i++) {
                        if (window[i].getNumber() != sequenceNum){
                            System.out.print(window[i].getNumber() + window[i].getAsterisk());
                            if (i < ((windowSize+windowTracker)-1)) { 
                                System.out.print(",");
                            }
                        }
                        else if (window[i].getAsterisk() == "-"){
                            System.out.print("-");
                            if (i < ((windowSize+windowTracker)-1)) { 
                                System.out.print(",");
                            }                                        
                        }
                    }                                
                    System.out.println("]");
                }
                else {
                    sending = false;
                }
            }
        }
        catch(IOException e) {
            
        }
    }
}
