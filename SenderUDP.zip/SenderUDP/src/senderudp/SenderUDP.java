package senderudp;

import java.net.*;
import java.util.*;
import java.io.*;
import java.nio.ByteBuffer;

/**
 * @author Dan Poss
 * @version Oct 1, 2015
 */

public class SenderUDP {

    public static void main(String[] args) {
        int windowSize = 0;
        int sequenceNum = 0;
        int missingPkt = 0;
        int windowTracker = 0;
        byte[] sendData = new byte[1024];
        byte[] rcvData = new byte[1024];
        boolean sending = true;
        int counter = 0;
        Scanner in = new Scanner(System.in);
        try{
            System.out.print("Enter the window's size on the sender: " );
            windowSize = in.nextInt();
            System.out.print("Enter the maximum sequence number on the sender: ");
            sequenceNum = in.nextInt();
            System.out.print("Select the packet(s) that will be dropped: ");
            missingPkt = in.nextInt();
            StringInt window[] = new StringInt[sequenceNum + windowSize];
            for (int i = 0; i < sequenceNum; i++) {
                window[i] = new StringInt(i, "");
            }
            for (int j = sequenceNum; j < windowSize+sequenceNum; j++) {
                window[j] = new StringInt(sequenceNum, "-");
            }
            DatagramSocket senderSocket = new DatagramSocket(9877);
            InetAddress IPAddress = InetAddress.getByName("localhost");
            int j = 0;
            DatagramPacket sendPkt[] = new DatagramPacket[sequenceNum];
            DatagramPacket rcvPkt = new DatagramPacket(rcvData, rcvData.length);
            while(sending) {
                if (j != sequenceNum) {
                    sendData[0] = (byte) sequenceNum;
                    sendData[1] = (byte) j;
                    window[j].setString("*");
                    System.out.println("Packet " + j + " is sent, window[" + window[windowTracker].getNumber() + window[windowTracker].getAsterisk() + ","
                            + window[windowTracker+1].getNumber() + window[windowTracker+1].getAsterisk() + "," 
                            + window[windowTracker+2].getNumber() + window[windowTracker+2].getAsterisk() + "," 
                            + window[windowTracker+3].getNumber() + window[windowTracker+3].getAsterisk() + "]");
                    sendPkt[j] = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
                    senderSocket.send(sendPkt[j]);
                    j++;
                    if (j > 3) {
                        senderSocket.receive(rcvPkt);
                        windowTracker++;
                        System.out.println("Ack " + rcvData[1] + " received, window["
                                + window[windowTracker].getNumber() + window[windowTracker].getAsterisk() + ","
                                + window[windowTracker+1].getNumber() + window[windowTracker+1].getAsterisk() + ","
                                + window[windowTracker+2].getNumber() + window[windowTracker+2].getAsterisk() + ","
                                + window[windowTracker+3].getNumber() + window[windowTracker+3].getAsterisk() + "]");
                        counter ++;
                    }
                } 
                else if(counter < sequenceNum) {
                    windowTracker++;
//                    if (window[counter].getNumber() == sequenceNum) {
//                        window[counter].setNumber() = "-";
//                    }
                    counter ++;
                    senderSocket.receive(rcvPkt);
                    System.out.println("Ack " + rcvData[1] + " received, window["
                                + window[windowTracker].getNumber() + window[windowTracker].getAsterisk() + ","
                                + window[windowTracker+1].getNumber() + window[windowTracker+1].getAsterisk() + "," 
                                + window[windowTracker+2].getNumber() + window[windowTracker+2].getAsterisk() + ","
                                + window[windowTracker+3].getNumber() + window[windowTracker+3].getAsterisk() + "]");
                }
                else {
                    sending = false;
                }
            }
        }
        catch(IOException e) {
            
        }
    }
}
