package senderudp;

import java.net.*;
import java.util.*;
import java.io.*;
import java.nio.ByteBuffer;

/**
 * @author Dan Poss
 * @version Oct 1, 2015
 */

public class SenderUDP {

    public static void main(String[] args) {
        int windowSize = 0;
        int sequenceNum = 0;
        int missingPkt = 0;
        int windowTracker = 0;
        StringInt window[] = new StringInt[10];
        window[0] = new StringInt(0," ");
        window[1] = new StringInt(1," ");
        window[2] = new StringInt(2," ");
        window[3] = new StringInt(3," ");
        window[4] = new StringInt(4," ");
        window[5] = new StringInt(5," ");
        window[6] = new StringInt(6," ");
        window[7] = new StringInt(7," ");
        window[8] = new StringInt(8," ");
        window[9] = new StringInt(9," ");
        boolean sending = true;
        Scanner in = new Scanner(System.in);
        try{
            System.out.print("Enter the window's size on the sender: " );
            windowSize = in.nextInt();
            System.out.print("Enter the maximum sequence number on the sender: ");
            sequenceNum = in.nextInt();
            System.out.print("Select the packet(s) that will be dropped: ");
            missingPkt = in.nextInt();
            DatagramSocket senderSocket = new DatagramSocket(9877);
            DatagramSocket recieverSocket = new DatagramSocket(9875);
            InetAddress IPAddress = InetAddress.getByName("localhost");
            int j = 0;
            DatagramPacket sendPkt[] = new DatagramPacket[sequenceNum];
            while(sending) {
                if (j != 10) {
                    byte[] sendData = new byte[1024];
                    byte[] rcvData = new byte[1024];
                    sendData[0] = (byte) sequenceNum;
                    sendData[1] = (byte) j;
                    window[j].setString("*");
                    if (j >= windowSize) 
                        windowTracker++;
                    System.out.println("Packet " + j + " is sent, window[" + window[windowTracker].getNumber() + window[windowTracker].getAsterisk() + ","
                            + window[windowTracker+1].getNumber() + window[windowTracker+1].getAsterisk() + "," 
                            + window[windowTracker+2].getNumber() + window[windowTracker+2].getAsterisk() + "," 
                            + window[windowTracker+3].getNumber() + window[windowTracker+3].getAsterisk() + "]");
                    sendPkt[j] = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
                    DatagramPacket rcvPkt = new DatagramPacket(rcvData, rcvData.length);
                    senderSocket.send(sendPkt[j]);
//                    recieverSocket.receive(rcvPkt);
                    j++;
                    if (rcvData[0] == (byte)1) {
                        System.out.println("Ack " + rcvData[1] + " received, window[]");
                    }
                } 
                else {
                    sending = false;
                }
            }
            
            System.exit(0);
        }
        catch(IOException e) {
            
        }
    }
}
