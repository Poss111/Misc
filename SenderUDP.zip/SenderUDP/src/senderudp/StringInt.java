package senderudp;


/**
 * @author Dan Poss
 * @date Oct 6, 2015
 */

public class StringInt {

    int number;
    String asterisk;
    
    StringInt(int number, String asterisk) {
        this.number = number;
        this.asterisk = asterisk;
    }
    
    public void setNumber(int num) {
        number = num;
    }
    
    public void setString(String ast) {
        asterisk = ast;
    }
    
    public int getNumber() {
        return number;
    }
    
    public String getAsterisk() {
        return asterisk;
    }
}
