package serialinput;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import RXTXcomm.gnu.io.*;
import java.util.Enumeration;

/**
 * @author Dan Poss
 * @version Oct 18, 2015
 */

public class SerialInput  implements SerialPortEventListener {

    public static void main(String[] args) {
        
    }

}
